## Volcanno Custom Post Types
### Plugin that registers custom post types.
**Author: Pixel Industry**

**Web: pixel-industry.com**

***

### CHANGELOG

**1.1.5**
* removed all calls to BFI_THUMB and replaced with WordPress native image functions

**1.1.4**
* Added Case Studies post type
* Added Photography post type

**1.1.3**
* [ Modified ] : Removed post formats from Catering post type.
* [ Modified ] : Menus post type changed to pi_dish_drinks

**1.1.2**
* [ Improved ] : Loading preview images in CPT's listing page. When image is smaller then 150 x 120, original sized image is loaded.

**1.1.1**
* Added fallback for Portfolio item preview image. BookMarks has new custom field name for image (now "volcannoimage", was "pf_image")

**1.1**
* Added Catering post type
* Added Menus post type

**1.0**
* Initial release