## Volcanno One Click Installer
### Plugin that helps setup theme by uploading predefined demo content.
**Author: Pixel Industry**

**Web: pixel-industry.com**

***

### CHANGELOG

**1.1**
* Compatibility with multi-layout themes

**1.0**
* Initial release